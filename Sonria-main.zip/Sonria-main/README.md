# Sonria!
Developed by Hannah Guillen, Mimi Tran, Aria Siriouthay, Tashia Boddu.

Sonria! is a web application that can help students better understand their mental health throughout the school year.